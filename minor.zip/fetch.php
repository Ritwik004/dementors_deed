<?php
$con=mysqli_connect("localhost","id1700129_parking","parking","id1700129_parking");
$email=$_GET["uname"];
$password=$_GET["psw"];
if(mysqli_connect_errno($con))
{
	echo "A102";
}
else
{
	$query="select * from registration where Email_Id='$email' and Password='$password'";
	$result=mysqli_query($con,$query);
if(mysqli_num_rows($result)==0)
{
echo "Incorrect Username or Password";
//echo $query;
}
else
{
	echo "login successful";
header("Location:main.html");
	
}
}
?>